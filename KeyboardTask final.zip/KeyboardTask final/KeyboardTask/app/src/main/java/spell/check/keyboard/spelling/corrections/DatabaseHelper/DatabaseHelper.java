package spell.check.keyboard.spelling.corrections.DatabaseHelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import spell.check.keyboard.spelling.corrections.Model.SuggestionModel;
import spell.check.keyboard.spelling.corrections.Utils.IConstant;

/* loaded from: classes.dex */
public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "SuggestionDb.db";
    public static final int DATABASE_VERSION = 1;
    private static String DB_PATH = "";
    public static final String TABLE_NAME_Suggestion = "tblSuggestionWord";
    private final Context mContext;
    private SQLiteDatabase mDataBase;

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onCreate(SQLiteDatabase sQLiteDatabase) {
    }

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 1);
        if (Build.VERSION.SDK_INT >= 17) {
            DB_PATH = context.getApplicationInfo().dataDir + "/databases/";
        } else {
            DB_PATH = "/data/data/" + context.getPackageName() + "/databases/";
        }
        this.mContext = context;
        copyDataBase();
        getReadableDatabase();
    }

    private boolean checkDataBase() {
        return new File(DB_PATH + DATABASE_NAME).exists();
    }

    private void copyDataBase() {
        if (checkDataBase()) {
            return;
        }
        getReadableDatabase();
        close();
        try {
            copyDBFile();
        } catch (IOException unused) {
            throw new Error("ErrorCopyingDataBase");
        }
    }

    private void copyDBFile() throws IOException {
        InputStream open = this.mContext.getAssets().open(DATABASE_NAME);
        FileOutputStream fileOutputStream = new FileOutputStream(DB_PATH + DATABASE_NAME);
        byte[] bArr = new byte[1024];
        while (true) {
            int read = open.read(bArr);
            if (read > 0) {
                fileOutputStream.write(bArr, 0, read);
            } else {
                fileOutputStream.flush();
                fileOutputStream.close();
                open.close();
                return;
            }
        }
    }

    @Override // android.database.sqlite.SQLiteOpenHelper, java.lang.AutoCloseable
    public synchronized void close() {
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        if (sQLiteDatabase != null) {
            sQLiteDatabase.close();
        }
        super.close();
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        onCreate(sQLiteDatabase);
    }

    public ArrayList<SuggestionModel> getSuggestions(String str) {
        ArrayList<SuggestionModel> arrayList = new ArrayList<>();
        Cursor rawQuery = getReadableDatabase().rawQuery("SELECT * FROM tblSuggestionWord WHERE " + IConstant.sWord + " LIKE '" + str + "%' order by " + IConstant.frequently_used + " DESC", null);
        if (rawQuery != null) {
            while (rawQuery.moveToNext()) {
                int i = rawQuery.getInt(rawQuery.getColumnIndex(IConstant.sId));
                String string = rawQuery.getString(rawQuery.getColumnIndex(IConstant.sWord));
                int i2 = rawQuery.getInt(rawQuery.getColumnIndex(IConstant.frequently_used));
                SuggestionModel suggestionModel = new SuggestionModel();
                suggestionModel.setId(i);
                suggestionModel.setWord(string);
                suggestionModel.setFrequentlyUsed(i2);
                arrayList.add(suggestionModel);
            }
        }
        return arrayList;
    }

    public Boolean updateFrequentlyWord(int i) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(IConstant.frequently_used, (Integer) 1);
        int update = writableDatabase.update(TABLE_NAME_Suggestion, contentValues, "Id= '" + i + "'", null);
        writableDatabase.close();
        if (update == 0) {
            return false;
        }
        return true;
    }

    public Boolean addWord(String str) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(IConstant.sWord, str);
        contentValues.put(IConstant.frequently_used, (Integer) 1);
        long insert = writableDatabase.insert(TABLE_NAME_Suggestion, null, contentValues);
        writableDatabase.close();
        if (insert == -1) {
            return false;
        }
        return true;
    }
}
