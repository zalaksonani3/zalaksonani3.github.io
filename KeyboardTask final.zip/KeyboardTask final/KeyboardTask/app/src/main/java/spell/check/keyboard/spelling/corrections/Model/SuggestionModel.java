package spell.check.keyboard.spelling.corrections.Model;

/* loaded from: classes.dex */
public class SuggestionModel {
    int FrequentlyUsed;
    int Id;
    String Word;

    public int getId() {
        return this.Id;
    }

    public void setId(int i) {
        this.Id = i;
    }

    public String getWord() {
        return this.Word;
    }

    public void setWord(String str) {
        this.Word = str;
    }

    public int getFrequentlyUsed() {
        return this.FrequentlyUsed;
    }

    public void setFrequentlyUsed(int i) {
        this.FrequentlyUsed = i;
    }
}
