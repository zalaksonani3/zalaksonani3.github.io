package spell.check.keyboard.spelling.corrections.grammer.myapplication.api;



import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import spell.check.keyboard.spelling.corrections.grammer.myapplication.model.request.CompletionRequest;
import spell.check.keyboard.spelling.corrections.grammer.myapplication.model.response.CompletionResponse;

public interface ApiInterface {
    @Headers({"Content-Type: application/json"})
    @POST("v1/chat/completions")
    Call<CompletionResponse> chatCompletion(@Header("Authorization") String authorization,
                                            @Body CompletionRequest request);
}
