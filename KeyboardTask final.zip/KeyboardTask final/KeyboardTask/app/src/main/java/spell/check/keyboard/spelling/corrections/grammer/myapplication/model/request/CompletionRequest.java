
package spell.check.keyboard.spelling.corrections.grammer.myapplication.model.request;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import spell.check.keyboard.spelling.corrections.grammer.myapplication.model.response.Message;

public class CompletionRequest {

    @SerializedName("model")
    @Expose
    private String model;
    @SerializedName("messages")
    @Expose
    private List<Message> messages;
    @SerializedName("temperature")
    @Expose
    private Double temperature;
    @SerializedName("max_tokens")
    @Expose
    private Integer maxTokens;
    @SerializedName("top_p")
    @Expose
    private Integer topP;

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public List<Message> getMessages() {
        return messages;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }

    public Double getTemperature() {
        return temperature;
    }

    public void setTemperature(Double temperature) {
        this.temperature = temperature;
    }

    public Integer getMaxTokens() {
        return maxTokens;
    }

    public void setMaxTokens(Integer maxTokens) {
        this.maxTokens = maxTokens;
    }

    public Integer getTopP() {
        return topP;
    }

    public void setTopP(Integer topP) {
        this.topP = topP;
    }

    @Override
    public String toString() {
        return "CompletionRequest{" +
                "model='" + model + '\'' +
                ", messages=" + messages +
                ", temperature=" + temperature +
                ", maxTokens=" + maxTokens +
                ", topP=" + topP +
                '}';
    }
}
