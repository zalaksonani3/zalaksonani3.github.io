package spell.check.keyboard.spelling.corrections.grammer.myapplication.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;


import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import spell.check.keyboard.spelling.corrections.R;
import spell.check.keyboard.spelling.corrections.grammer.myapplication.api.ApiClient;
import spell.check.keyboard.spelling.corrections.grammer.myapplication.api.ApiInterface;
import spell.check.keyboard.spelling.corrections.grammer.myapplication.model.request.CompletionRequest;
import spell.check.keyboard.spelling.corrections.grammer.myapplication.model.response.CompletionResponse;
import spell.check.keyboard.spelling.corrections.grammer.myapplication.model.response.Message;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private ApiInterface apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.e(TAG, "onCreate: " );

        getgrammerapi();
    }



    public void getgrammerapi(){


        List<Message> messageList = new ArrayList<>();

        //TODO: this is instructionMessage is required every time
        Message instructionMessage = new Message();
        instructionMessage.setRole("system");
        instructionMessage.setContent("You will be provided with statements, and your task is to convert them to standard English.");

        messageList.add(instructionMessage);

        //TODO: this is demo userInput chat gtp will response with grammar correction
        Message userInput = new Message();
        userInput.setRole("user");
        userInput.setContent("She no went to the market.");

        messageList.add(userInput);

        callApi(messageList);
    }

    private void callApi(List<Message> messages) {
        apiInterface = ApiClient.getApiInterface();
        CompletionRequest completionRequest = new CompletionRequest();
        completionRequest.setModel("gpt-3.5-turbo");
        completionRequest.setMessages(messages);
        completionRequest.setMaxTokens(70);
        completionRequest.setTemperature(1.0d);

        Call<CompletionResponse> call = apiInterface.chatCompletion("Bearer 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", completionRequest);


        call.enqueue(new Callback<CompletionResponse>() {
            @Override
            public void onResponse(@NonNull Call<CompletionResponse> call, @NonNull Response<CompletionResponse> response) {


                if (response.isSuccessful()) {
                    CompletionResponse completionResponse = response.body();
                    if (completionResponse != null) {
                        Toast.makeText(MainActivity.this, "response: " + completionResponse.toString(), Toast.LENGTH_SHORT).show();

                        if (completionResponse.getChoices().size() > 0) {
                            if (completionResponse.getChoices().get(0).getMessage().getContent() != null || !completionResponse.getChoices().get(0).getMessage().getContent().isEmpty()) {
                                Log.e(TAG, "onResponse: " + completionResponse.getChoices().get(0).getMessage().getContent());
                            }else{
                                //TODO: show same message with un susses message because cant correct grammar or no grammar correction available
                            }
                        }else{
                            //TODO: show same message with un susses message because cant correct grammar or no grammar correction available
                        }

                    } else {
                        Log.e(TAG, "onResponse: null response" );
                        //TODO: show same message with un susses message because cant correct grammar or no grammar correction available
                    }
                } else {
                    Log.e(TAG, "onResponse: unsuccessful" );
                    //TODO: show same message with un susses message because cant correct grammar or no grammar correction available
                }
            }

            @Override
            public void onFailure(@NonNull Call<CompletionResponse> call, @NonNull Throwable t) {
                Log.e(TAG, "onFailure: " + call + " " + t.getMessage());
            }
        });
    }

}     