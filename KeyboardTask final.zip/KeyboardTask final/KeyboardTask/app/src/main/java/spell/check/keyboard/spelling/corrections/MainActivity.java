package spell.check.keyboard.spelling.corrections;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    public static final String ACTION_CLOSE = "ACTION_CLOSE";
    public static boolean SpellkInter = true;
    Context context;
    private FirstReceiver firstReceiver;
    RelativeLayout layout;
    LinearLayout li_enablekeyboard;
    Toolbar toolbar;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        Bundle bundle2 = new Bundle();
        bundle2.putInt("SpellKOpenHomeScreenId", 1);
        getWindow().setFlags(67108864, 67108864);
        this.context = this;
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.toolbar = toolbar;
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        this.toolbar.setOverflowIcon(ContextCompat.getDrawable(this, R.drawable.ic_more));
        this.layout = (RelativeLayout) findViewById(R.id.adView);

        this.li_enablekeyboard = (LinearLayout) findViewById(R.id.li_enablekeyboard);

        this.li_enablekeyboard.setOnClickListener(new View.OnClickListener() {
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Bundle bundle3 = new Bundle();
                bundle3.putInt("SpellKHomeEnableKeyboardBtnClickId", view.getId());
                Intent intent = new Intent(MainActivity.this, EnableKeyboardActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                MainActivity.this.startActivity(intent);
            }
        });

        IntentFilter intentFilter = new IntentFilter("ACTION_CLOSE");
        FirstReceiver firstReceiver = new FirstReceiver();
        this.firstReceiver = firstReceiver;
        registerReceiver(firstReceiver, intentFilter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }



    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    @Override
    public void onBackPressed() {
        finish();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(this.firstReceiver);
    }


    class FirstReceiver extends BroadcastReceiver {
        FirstReceiver() {
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            Log.e("FirstReceiver", "FirstReceiver");
            if (intent.getAction().equals("ACTION_CLOSE")) {
                MainActivity.this.finish();
            }
        }
    }
}
