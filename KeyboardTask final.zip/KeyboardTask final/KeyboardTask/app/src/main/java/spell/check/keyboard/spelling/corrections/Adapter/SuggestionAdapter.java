package spell.check.keyboard.spelling.corrections.Adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import spell.check.keyboard.spelling.corrections.Model.SuggestionModel;
import spell.check.keyboard.spelling.corrections.OnClickInterface.OnItemClickListener;
import spell.check.keyboard.spelling.corrections.R;

/* loaded from: classes.dex */
public class SuggestionAdapter extends RecyclerView.Adapter<SuggestionAdapter.MyViewHolder> {
    public ArrayList<SuggestionModel> dataSet;
    private OnItemClickListener itemListener;
    public Context mContext;

    /* loaded from: classes.dex */
    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        LinearLayout llTextClick;
        TextView tvSuggestionText;

        public MyViewHolder(View view) {
            super(view);
            this.tvSuggestionText = (TextView) view.findViewById(R.id.tvSuggestionText);
            LinearLayout linearLayout = (LinearLayout) view.findViewById(R.id.llTextClick);
            this.llTextClick = linearLayout;
            linearLayout.setOnClickListener(this);
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            SuggestionAdapter.this.itemListener.OnClick(view, getLayoutPosition());
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_suggestion, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        TextView textView = myViewHolder.tvSuggestionText;
        textView.setText("" + this.dataSet.get(i).getWord());
      /*  if (MainUtils.getThemeSelected(this.mContext)) {
            int keyboardTheme = MainUtils.getKeyboardTheme(this.mContext);
            if (keyboardTheme == 0) {
                myViewHolder.tvSuggestionText.setTextColor(ContextCompat.getColor(this.mContext, R.color.colorThemeTextColor1));
                myViewHolder.llTextClick.setBackgroundResource(R.drawable.t1_key);
                return;
            } else if (keyboardTheme == 1) {
                myViewHolder.tvSuggestionText.setTextColor(ContextCompat.getColor(this.mContext, R.color.colorThemeTextColor2));
                myViewHolder.llTextClick.setBackgroundResource(R.drawable.t2_key);
                return;
            } else if (keyboardTheme == 2) {
                myViewHolder.tvSuggestionText.setTextColor(ContextCompat.getColor(this.mContext, R.color.colorThemeTextColor3));
                myViewHolder.llTextClick.setBackgroundResource(R.drawable.t3_key);
                return;
            } else if (keyboardTheme == 3) {
                myViewHolder.tvSuggestionText.setTextColor(ContextCompat.getColor(this.mContext, R.color.colorThemeTextColor4));
                myViewHolder.llTextClick.setBackgroundResource(R.drawable.t4_key);
                return;
            } else if (keyboardTheme == 4) {
                myViewHolder.tvSuggestionText.setTextColor(ContextCompat.getColor(this.mContext, R.color.colorThemeTextColor5));
                myViewHolder.llTextClick.setBackgroundResource(R.drawable.t5_key);
                return;
            } else if (keyboardTheme == 5) {
                myViewHolder.tvSuggestionText.setTextColor(ContextCompat.getColor(this.mContext, R.color.colorThemeTextColor6));
                myViewHolder.llTextClick.setBackgroundResource(R.drawable.t6_key);
                return;
            } else if (keyboardTheme == 6) {
                myViewHolder.tvSuggestionText.setTextColor(ContextCompat.getColor(this.mContext, R.color.colorThemeTextColor7));
                myViewHolder.llTextClick.setBackgroundResource(R.drawable.t7_key);
                return;
            } else if (keyboardTheme == 7) {
                myViewHolder.tvSuggestionText.setTextColor(ContextCompat.getColor(this.mContext, R.color.colorThemeTextColor8));
                myViewHolder.llTextClick.setBackgroundResource(R.drawable.t8_key);
                return;
            } else if (keyboardTheme == 8) {
                myViewHolder.tvSuggestionText.setTextColor(ContextCompat.getColor(this.mContext, R.color.colorThemeTextColor9));
                myViewHolder.llTextClick.setBackgroundResource(R.drawable.t9_key);
                return;
            } else if (keyboardTheme == 9) {
                myViewHolder.tvSuggestionText.setTextColor(ContextCompat.getColor(this.mContext, R.color.colorThemeTextColor10));
                myViewHolder.llTextClick.setBackgroundResource(R.drawable.t10_key);
                return;
            } else {
                return;
            }
        }*/
        myViewHolder.tvSuggestionText.setTextColor(ContextCompat.getColor(this.mContext, R.color.colorThemeTextColor1));
        myViewHolder.llTextClick.setBackgroundResource(R.drawable.suggestion_bg);
    }

    public SuggestionAdapter(ArrayList<SuggestionModel> arrayList, Context context, OnItemClickListener onItemClickListener) {
        this.dataSet = arrayList;
        this.mContext = context;
        this.itemListener = onItemClickListener;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.dataSet.size();
    }

    private static boolean shouldShow(Context context) {
        if (context != null && context == context.getApplicationContext() && (context instanceof Activity)) {
            return shouldShow((Activity) context);
        }
        return true;
    }

    private static boolean shouldShow(Activity activity) {
        Window window;
        View decorView;
        return (activity == null || activity.isFinishing() || (window = activity.getWindow()) == null || (decorView = window.getDecorView()) == null || decorView.getVisibility() != View.VISIBLE) ? false : true;
    }
}
