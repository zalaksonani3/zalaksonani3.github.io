package spell.check.keyboard.spelling.corrections;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SpellCheckActivity extends AppCompatActivity {

    private EditText editText;
    private Button grammarCheckButton;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spell_check);
        editText = findViewById(R.id.editText);
        grammarCheckButton = findViewById(R.id.grammarCheckButton);
        resultTextView = findViewById(R.id.resultTextView);

        grammarCheckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                performGrammarCheck();
            }
        });
    }
   /* JLanguageTool languageTool;
    private void performGrammarCheck() {
        String inputText = editText.getText().toString();

        JLanguageTool langTool = new JLanguageTool(Languages.getLanguageForShortCode("en-GB"));
        // comment in to use statistical ngram data:
        //langTool.activateLanguageModelRules(new File("/data/google-ngram-data"));
        List<RuleMatch> matches = null;
        try {
            matches = langTool.check("A sentence with a error in the Hitchhiker's Guide tot he Galaxy");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        for (RuleMatch match : matches) {
            System.out.println("Potential error at characters " +
                    match.getFromPos() + "-" + match.getToPos() + ": " +
                    match.getMessage());
            System.out.println("Suggested correction(s): " +
                    match.getSuggestedReplacements());
        }
    }*/
}