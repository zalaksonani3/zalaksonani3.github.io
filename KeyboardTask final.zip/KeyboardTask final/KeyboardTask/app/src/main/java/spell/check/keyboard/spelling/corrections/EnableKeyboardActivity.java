package spell.check.keyboard.spelling.corrections;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import java.util.List;

import spell.check.keyboard.spelling.corrections.enablekeyboard.FontSet;

/* loaded from: classes.dex */
public final class EnableKeyboardActivity extends AppCompatActivity {
    public static Activity activity;
    Context context;
    InputMethodChangeReceiver inputMethodChangeReceiver;
    InputMethodManager inputMethodManager;
    RelativeLayout layout;
    LinearLayout li_enablekeyboard;
    List<InputMethodInfo> list;
    LinearLayout llDisableKeyboardView;
    LinearLayout llEnableKeyboardView;
    private int mState;
    boolean onBackClick;
    String packageLocal;
    public Intent reLaunchTaskIntent;
    Toolbar toolbar;
    public final Handler mGetBackHereHandler = new Handler() { // from class: spell.check.keyboard.spelling.corrections.EnableKeyboardActivity.1
        @Override // android.os.Handler
        public void handleMessage(Message message) {
            int i = message.what;
            if (i == 446) {
                Intent intent = EnableKeyboardActivity.this.reLaunchTaskIntent;
            } else if (i == 447) {
                EnableKeyboardActivity.this.unregisterSettingsObserverNow();
            } else {
                super.handleMessage(message);
            }
        }
    };
    private final ContentObserver secureSettingsChanged = new ContentObserver(null) { // from class: spell.check.keyboard.spelling.corrections.EnableKeyboardActivity.2
        @Override // android.database.ContentObserver
        public boolean deliverSelfNotifications() {
            return false;
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean z) {
            EnableKeyboardActivity enableKeyboardActivity = EnableKeyboardActivity.this;
            Log.d("secureSettingsChange", String.valueOf(enableKeyboardActivity.isKeyboardEnabled(enableKeyboardActivity.getApplicationContext())));
            EnableKeyboardActivity enableKeyboardActivity2 = EnableKeyboardActivity.this;
            if (enableKeyboardActivity2.isKeyboardEnabled(enableKeyboardActivity2.getApplicationContext())) {
                EnableKeyboardActivity.this.mGetBackHereHandler.removeMessages(446);
                EnableKeyboardActivity.this.mGetBackHereHandler.sendMessageDelayed(EnableKeyboardActivity.this.mGetBackHereHandler.obtainMessage(446), 50L);
            }
        }
    };

    /* loaded from: classes.dex */
    public class InputMethodChangeReceiver extends BroadcastReceiver {
        public InputMethodChangeReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("android.intent.action.INPUT_METHOD_CHANGED") && FontSet.INSTANCE.isThisKeyboardSetAsDefaultIME(context)) {
                EnableKeyboardActivity.this.onBackClick = false;
            }
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_enablekeyboard);
//        this.mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle2 = new Bundle();
        bundle2.putInt("SpellKOpenEnableKeyboardScreenId", 2);
//        this.mFirebaseAnalytics.logEvent("SpellKOpenEnableKeyboardScreen", bundle2);
        this.context = this;
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.toolbar = toolbar;
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        this.toolbar.setOverflowIcon(ContextCompat.getDrawable(this, R.drawable.ic_more));
        this.layout = (RelativeLayout) findViewById(R.id.adView);

        InputMethodChangeReceiver inputMethodChangeReceiver = new InputMethodChangeReceiver();
        this.inputMethodChangeReceiver = inputMethodChangeReceiver;
        registerReceiver(inputMethodChangeReceiver, new IntentFilter("android.intent.action.INPUT_METHOD_CHANGED"));
        this.mState = 0;
        this.packageLocal = getApplicationContext().getPackageName();
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        this.inputMethodManager = inputMethodManager;
        this.list = inputMethodManager.getEnabledInputMethodList();
        this.reLaunchTaskIntent = new Intent(getBaseContext(), EnableKeyboardActivity.class);
        this.li_enablekeyboard = (LinearLayout) findViewById(R.id.li_enablekeyboard);
        this.llEnableKeyboardView = (LinearLayout) findViewById(R.id.llEnableKeyboardView);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.llDisableKeyboardView);
        this.llDisableKeyboardView = linearLayout;
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: spell.check.keyboard.spelling.corrections.EnableKeyboardActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (EnableKeyboardActivity.this.isInputEnabled()) {
                    return;
                }
                EnableKeyboardActivity.this.enableKeyboard(view);
            }
        });
        this.llEnableKeyboardView.setOnClickListener(new View.OnClickListener() { // from class: spell.check.keyboard.spelling.corrections.EnableKeyboardActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Toast makeText = Toast.makeText(EnableKeyboardActivity.this, "Already Keyboard Service Enabled.", 1);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
        });
        this.li_enablekeyboard.setOnClickListener(new View.OnClickListener() { // from class: spell.check.keyboard.spelling.corrections.EnableKeyboardActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (FontSet.INSTANCE.isThisKeyboardSetAsDefaultIME(EnableKeyboardActivity.this.context)) {
                    EnableKeyboardActivity.this.onBackClick = false;
                    Toast makeText = Toast.makeText(EnableKeyboardActivity.this, "Already Keyboard Selected.", 1);
                    makeText.setGravity(17, 0, 0);
                    makeText.show();
                    return;
                }
                EnableKeyboardActivity.this.openKeyboardChooser();
            }
        });
        if (isInputEnabled()) {
            this.llEnableKeyboardView.setVisibility(0);
            this.llDisableKeyboardView.setVisibility(8);
            return;
        }
        this.llEnableKeyboardView.setVisibility(8);
        this.llDisableKeyboardView.setVisibility(0);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (isInputEnabled()) {
            this.llEnableKeyboardView.setVisibility(0);
            this.llDisableKeyboardView.setVisibility(8);
        } else {
            this.llEnableKeyboardView.setVisibility(8);
            this.llDisableKeyboardView.setVisibility(0);
        }
        activity = this;
    }

    @Override
    public void onStart() {
        super.onStart();
        this.mGetBackHereHandler.removeMessages(446);
        unregisterSettingsObserverNow();
    }

    public boolean isInputEnabled() {
        List<InputMethodInfo> enabledInputMethodList = ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).getEnabledInputMethodList();
        int size = enabledInputMethodList.size();
        boolean z = false;
        for (int i = 0; i < size; i++) {
            InputMethodInfo inputMethodInfo = enabledInputMethodList.get(i);
            Log.d("INPUT ID", String.valueOf(inputMethodInfo.getId()));
            if (inputMethodInfo.getId().contains(getPackageName())) {
                z = true;
            }
        }
        return z;
    }

    public void unregisterSettingsObserverNow() {
        this.mGetBackHereHandler.removeMessages(447);
        getApplicationContext().getContentResolver().unregisterContentObserver(this.secureSettingsChanged);
    }

    public void openKeyboardChooser() {
        if (isInputEnabled()) {
            Object systemService = getSystemService(Context.INPUT_METHOD_SERVICE);
            if (systemService != null) {
                this.mState = 1;
                ((InputMethodManager) systemService).showInputMethodPicker();
                return;
            }
            return;
        }
        Toast makeText = Toast.makeText(this, "Please Enable Keyboard.", 1);
        makeText.setGravity(17, 0, 0);
        makeText.show();
    }

    public void enableKeyboard(View view) {
        getApplicationContext().getContentResolver().registerContentObserver(Settings.Secure.CONTENT_URI, true, this.secureSettingsChanged);
        this.mGetBackHereHandler.removeMessages(447);
        Handler handler = this.mGetBackHereHandler;
        handler.sendMessageDelayed(handler.obtainMessage(447), 45000L);
        try {
            startActivity(new Intent("android.settings.INPUT_METHOD_SETTINGS"));
        } catch (ActivityNotFoundException unused) {
            Toast makeText = Toast.makeText(this, (int) R.string.setup_wizard_step_one_action_error_no_settings_activity, 1);
            makeText.setGravity(17, 0, 0);
            makeText.show();
        }
    }

    public final boolean isKeyboardEnabled(Context context) {
        return FontSet.INSTANCE.isThisKeyboardEnabled(context);
    }

    @Override
    public void onDestroy() {
        unregisterReceiver(this.inputMethodChangeReceiver);
        super.onDestroy();
    }

    public static String combinePath(String str, String str2) {
        if (TextUtils.isEmpty(str)) {
            str = str2;
        } else if (!TextUtils.isEmpty(str2)) {
            if (!str.endsWith("/")) {
                str = str + "/";
            }
            if (str2.startsWith("/")) {
                str = str + str2.substring(1);
            } else {
                str = str + str2;
            }
        }
        return TextUtils.isEmpty(str) ? "" : str;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        if (MainActivity.SpellkInter) {
            MainActivity.SpellkInter = false;
            return;
        }
        MainActivity.SpellkInter = true;

    }


}
