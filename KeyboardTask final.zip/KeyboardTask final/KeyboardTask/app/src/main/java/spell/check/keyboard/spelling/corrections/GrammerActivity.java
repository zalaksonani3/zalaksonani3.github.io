package spell.check.keyboard.spelling.corrections;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import spell.check.keyboard.spelling.corrections.Model.APIResponse;
import spell.check.keyboard.spelling.corrections.Model.ApiClient;
import spell.check.keyboard.spelling.corrections.Model.ApiInterface;
import spell.check.keyboard.spelling.corrections.Model.Requestclass;

public class GrammerActivity extends AppCompatActivity {

    ApiInterface apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grammer);





    }

//    private void AddChat(List<ApiRequestMessage> messages) {
//        apiInterface = ApiClient.getApiInterface();
//        Requestclass request = new Requestclass();
//        request.setModel("gpt-3.5-turbo");
//        request.setMessages(messages);
//        request.setMaxTokens(70);
//        request.setTemperature(1.0f);
//        request.setPresencePenalty(0.5f); // Lower presence penalty for more natural and diverse responses
//        request.setFrequencyPenalty(0.5f); // Lower frequency penalty for less repetition in responses
//
//        Call<APIResponse> call = apiInterface.chatCompletion("Bearer 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", request);
//        call.enqueue(new Callback<APIResponse>() {
//            @Override
//            public void onResponse(@NonNull Call<APIResponse> call, @NonNull Response<APIResponse> response) {
//                if (response.isSuccessful()) {
//                    APIResponse completionResponse = response.body();
//                    if (completionResponse != null) {
//                    }
//                } else {
//                    Log.e(TAG, "onResponse: " + "error");
//                }
//            }
//
//            @Override
//            public void onFailure(@NonNull Call<APIResponse> call, @NonNull Throwable t) {
//                Log.e(TAG, "onFailure: " + call + " " + t.getMessage());
//            }
//        });
//    }

}