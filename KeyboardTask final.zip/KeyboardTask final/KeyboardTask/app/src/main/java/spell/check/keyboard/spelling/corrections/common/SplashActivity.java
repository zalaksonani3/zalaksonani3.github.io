package spell.check.keyboard.spelling.corrections.common;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

import spell.check.keyboard.spelling.corrections.MainActivity;
import spell.check.keyboard.spelling.corrections.R;

/* loaded from: classes.dex */
public class SplashActivity extends AppCompatActivity {



    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(67108864, 67108864);
        setContentView(R.layout.splashactivity);

        startActivity(new Intent(this, MainActivity.class));
        finish();
    }












    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        super.onBackPressed();
        ExitApp();
    }

    public void ExitApp() {
        moveTaskToBack(true);
        finish();
        Process.killProcess(Process.myPid());
        System.exit(0);
    }
}
