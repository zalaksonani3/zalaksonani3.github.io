package spell.check.keyboard.spelling.corrections.Utils;

/* loaded from: classes.dex */
public class IConstant {
    public static String frequently_used = "FrequentlyUsed";
    public static String sId = "Id";
    public static String sWord = "Word";
}
