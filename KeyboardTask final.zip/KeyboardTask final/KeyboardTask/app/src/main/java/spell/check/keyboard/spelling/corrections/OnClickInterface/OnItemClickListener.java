package spell.check.keyboard.spelling.corrections.OnClickInterface;

import android.view.View;

/* loaded from: classes.dex */
public interface OnItemClickListener {
    void OnClick(View view, int i);
}
