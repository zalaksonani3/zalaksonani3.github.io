package spell.check.keyboard.spelling.corrections.Service;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.text.method.MetaKeyKeyListener;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.CompletionInfo;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import spell.check.keyboard.spelling.corrections.Adapter.SuggestionAdapter;
import spell.check.keyboard.spelling.corrections.DatabaseHelper.DatabaseHelper;
import spell.check.keyboard.spelling.corrections.Model.SuggestionModel;
import spell.check.keyboard.spelling.corrections.OnClickInterface.OnItemClickListener;
import spell.check.keyboard.spelling.corrections.R;
import spell.check.keyboard.spelling.corrections.enablekeyboard.SharedPreferenceclass;
import spell.check.keyboard.spelling.corrections.grammer.myapplication.activity.MainActivity;
import spell.check.keyboard.spelling.corrections.grammer.myapplication.api.ApiClient;
import spell.check.keyboard.spelling.corrections.grammer.myapplication.api.ApiInterface;
import spell.check.keyboard.spelling.corrections.grammer.myapplication.model.request.CompletionRequest;
import spell.check.keyboard.spelling.corrections.grammer.myapplication.model.response.CompletionResponse;
import spell.check.keyboard.spelling.corrections.grammer.myapplication.model.response.Message;

/* loaded from: classes.dex */
public class SimpleIME extends InputMethodService implements KeyboardView.OnKeyboardActionListener, SharedPreferences.OnSharedPreferenceChangeListener, OnItemClickListener {
    private static final List<String> EMPTY_LIST = new ArrayList();
    static final boolean PROCESS_HARD_KEYS = true;
    Context context;
    CharSequence currentSuggestion;
    DatabaseHelper databaseHelper;
    private SharedPreferences.Editor editor;
    private Keyboard enSymbolsCKeyboard;
    private Keyboard enSymbolsKeyboard;

    String TAG = "SimpleIME";

    View kv;

    private boolean mAutoCompletionOn;
    private boolean mCapsLock;
    private boolean mCapsLocked;
    private boolean mCompletionOn;
    private CompletionInfo[] mCompletions;
    private Keyboard mCurKeyboard;
    private Keyboard mEngKeyboard;
    private Keyboard mEngKeyboardC;
    private Keyboard mEngKeyboardShift;
    private InputMethodManager mInputMethodManager;
    private KeyboardView mInputView;
    private long mMetaState;
    private boolean mPredictionOn;
    private boolean mPreview;
    private SharedPreferences mSharedPreferences;
    private String mSpecialSeparators;
    private String mWordSeparators;

    RelativeLayout rl_suggestion;
    RecyclerView rvSuggestions;
    public SharedPreferenceclass sharedPreferenceAapnar;
    SharedPreferences sharedPreferences;

    SuggestionAdapter suggestionAdapter;
    private int lngCode = 0;
    private String mAutoSpace = "";
    private StringBuilder mComposing = new StringBuilder();
    ArrayList<SuggestionModel> suggestionModels = new ArrayList<>();


    TextView spell_check_txt;
    TextView apply_txt;
    TextView correct_txt;
    TextView txt_result;
    ImageView spell_check_btn;
    ImageView close_btn;
    RelativeLayout lin_spellcheck;
    LinearLayout lin_trans;
    ProgressBar progressbar1;

    String correct_grammer="";
    String final_all_txt="";

    @Override
    public void swipeUp() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        this.context = this;
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        this.mSharedPreferences = defaultSharedPreferences;
        defaultSharedPreferences.registerOnSharedPreferenceChangeListener(this);
        this.lngCode = this.mSharedPreferences.getInt("INPUT_LANGUAGE", 0);
        this.mInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        this.mWordSeparators = getResources().getString(R.string.word_separators);
        this.mSpecialSeparators = getResources().getString(R.string.special_separators);
        this.sharedPreferenceAapnar = new SharedPreferenceclass(this);
        this.sharedPreferences = getSharedPreferences("key", 0);
        EMPTY_LIST.add("the");
    }

    @Override // android.inputmethodservice.InputMethodService
    public void onInitializeInterface() {

        this.mEngKeyboard = new Keyboard(this, R.xml.qwerty_eng);
        this.mEngKeyboardC = new Keyboard(this, R.xml.qwerty_eng_c);
        this.mEngKeyboardShift = new Keyboard(this, R.xml.qwerty_eng_shift);
        this.enSymbolsKeyboard = new Keyboard(this, R.xml.symbols_eng);
        this.enSymbolsCKeyboard = new Keyboard(this, R.xml.symbols_eng2);
    }

    @Override // android.inputmethodservice.InputMethodService
    public View onCreateInputView() {

        this.kv = getLayoutInflater().inflate(R.layout.keyboard, (ViewGroup) null);

        KeyboardView keyboardView = (KeyboardView) this.kv.findViewById(R.id.keyboard);
        this.mInputView = keyboardView;
        keyboardView.setOnKeyboardActionListener(this);
        loadPreviewPreferences(this.mSharedPreferences);
        loadAutocompletionPreferences(this.mSharedPreferences);
        loadPredictionPreferences(this.mSharedPreferences);
        setKeyboardLanguage();
        this.mInputView.setPreviewEnabled(false);
        this.rvSuggestions = (RecyclerView) this.kv.findViewById(R.id.rvSuggestions);

        this.rl_suggestion = (RelativeLayout) this.kv.findViewById(R.id.rl_suggestion);

        spell_check_btn = this.kv.findViewById(R.id.spell_check_btn);
        close_btn = this.kv.findViewById(R.id.close_btn);
        lin_spellcheck = this.kv.findViewById(R.id.lin_spellcheck);
        lin_trans = this.kv.findViewById(R.id.lin_trans);
        correct_txt = this.kv.findViewById(R.id.correct_txt);
        txt_result = this.kv.findViewById(R.id.txt_result);
        spell_check_txt = this.kv.findViewById(R.id.spell_check_txt);
        progressbar1 = this.kv.findViewById(R.id.progressbar1);
        apply_txt = this.kv.findViewById(R.id.apply_txt);

        lin_spellcheck.setVisibility(View.GONE);
        lin_trans.setVisibility(View.VISIBLE);
        mInputView.setVisibility(View.VISIBLE);

        progressbar1.setVisibility(View.VISIBLE);
        correct_txt.setVisibility(View.GONE);
        txt_result.setVisibility(View.GONE);


        spell_check_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {




//                correct_grammer="correct grammer";





            }
        });
        apply_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InputConnection inputConnection = getCurrentInputConnection();
                int existingTextLength = 1000; // You may adjust this based on your requirements
                inputConnection.deleteSurroundingText(existingTextLength, 0);
                inputConnection.commitText(correctGrammerapi, correctGrammerapi.length());

            }
        });

        spell_check_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lin_spellcheck.setVisibility(View.VISIBLE);
                lin_trans.setVisibility(View.GONE);
                mInputView.setVisibility(View.GONE);

                InputConnection inputConnection = getCurrentInputConnection();

                // Now you can use inputConnection to get the text the user is typing
                CharSequence textBeingTyped = inputConnection.getTextBeforeCursor(1000, 0);

                // Do something with the typed text
                Log.d("Typed Text", textBeingTyped.toString());

                correct_txt.setText(textBeingTyped.toString());

                 final_all_txt=textBeingTyped.toString();

                progressbar1.setVisibility(View.VISIBLE);
                correct_txt.setVisibility(View.GONE);
                txt_result.setVisibility(View.GONE);

                getgrammerapi(final_all_txt);



            }
        });
        close_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lin_spellcheck.setVisibility(View.GONE);
                lin_trans.setVisibility(View.VISIBLE);
                mInputView.setVisibility(View.VISIBLE);


            }
        });


        this.rvSuggestions.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        this.rvSuggestions.setItemAnimator(new DefaultItemAnimator());
        this.databaseHelper = new DatabaseHelper(this);


        return this.kv;
    }
    private ApiInterface apiInterface;


    public void getgrammerapi(String txt){


        List<Message> messageList = new ArrayList<>();

        //TODO: this is instructionMessage is required every time
        Message instructionMessage = new Message();
        instructionMessage.setRole("system");
        instructionMessage.setContent("You will be provided with statements, and your task is to convert them to standard English.");

        messageList.add(instructionMessage);

        //TODO: this is demo userInput chat gtp will response with grammar correction
        Message userInput = new Message();
        userInput.setRole("user");
//        userInput.setContent("She no went to the market.");
        userInput.setContent(txt);

        messageList.add(userInput);

        callApi(messageList);
    }
    String correctGrammerapi;
    private void callApi(List<Message> messages) {
        apiInterface = ApiClient.getApiInterface();
        CompletionRequest completionRequest = new CompletionRequest();
        completionRequest.setModel("gpt-3.5-turbo");
        completionRequest.setMessages(messages);
        completionRequest.setMaxTokens(70);
        completionRequest.setTemperature(1.0d);

        Call<CompletionResponse> call = apiInterface.chatCompletion("Bearer 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", completionRequest);


        call.enqueue(new Callback<CompletionResponse>() {
            @Override
            public void onResponse(@NonNull Call<CompletionResponse> call, @NonNull Response<CompletionResponse> response) {

                if (response.isSuccessful()) {
                    CompletionResponse completionResponse = response.body();
                    if (completionResponse != null) {
                        Toast.makeText(context, "response: " + completionResponse.toString(), Toast.LENGTH_SHORT).show();

                        if (completionResponse.getChoices().size() > 0) {

                            if (completionResponse.getChoices().get(0).getMessage().getContent() != null || !completionResponse.getChoices().get(0).getMessage().getContent().isEmpty()) {
                                Log.e(TAG, "onResponse: " + completionResponse.getChoices().get(0).getMessage().getContent());


                                progressbar1.setVisibility(View.GONE);
                                correct_txt.setVisibility(View.VISIBLE);
                                txt_result.setVisibility(View.VISIBLE);
                                correctGrammerapi=completionResponse.getChoices().get(0).getMessage().getContent();


                                correct_txt.setText(correctGrammerapi);


                            }else{
                                //TODO: show same message with un susses message because cant correct grammar or no grammar correction available
                            }
                        }else{
                            //TODO: show same message with un susses message because cant correct grammar or no grammar correction available
                        }

                    } else {
                        Log.e(TAG, "onResponse: null response" );
                        //TODO: show same message with un susses message because cant correct grammar or no grammar correction available
                    }
                } else {
                    Log.e(TAG, "onResponse: unsuccessful" );
                    //TODO: show same message with un susses message because cant correct grammar or no grammar correction available
                }
            }

            @Override
            public void onFailure(@NonNull Call<CompletionResponse> call, @NonNull Throwable t) {
                Log.e(TAG, "onFailure: " + call + " " + t.getMessage());
            }
        });
    }



    @Override // android.inputmethodservice.InputMethodService
    public void onComputeInsets(InputMethodService.Insets insets) {
        super.onComputeInsets(insets);
        if (isFullscreenMode()) {
            return;
        }
        insets.contentTopInsets = insets.visibleTopInsets;
    }

    private void setKeyboardLanguage() {
        this.mInputView.setKeyboard(this.mEngKeyboard);
    }

    @Override // android.inputmethodservice.InputMethodService
    public void onStartInput(EditorInfo editorInfo, boolean z) {
        super.onStartInput(editorInfo, z);
        this.mComposing.setLength(0);
        updateCandidates();
        if (!z) {
            this.mMetaState = 0L;
        }
        this.mPredictionOn = false;
        this.mCompletionOn = false;
        this.mCompletions = null;
        int i = editorInfo.inputType & 15;
        if (i == 1) {
            if (this.lngCode == 0) {
                this.mCurKeyboard = this.mEngKeyboard;
            } else {
                this.mCurKeyboard = this.mEngKeyboard;
            }
            loadPredictionPreferences(this.mSharedPreferences);
            int i2 = editorInfo.inputType & 4080;
            if (i2 == 128 || i2 == 144) {
                this.mPredictionOn = false;
            }
            if (i2 == 32 || i2 == 16 || i2 == 176) {
                this.mPredictionOn = false;
            }
            if ((editorInfo.inputType & 65536) != 0) {
                this.mPredictionOn = false;
                this.mCompletionOn = isFullscreenMode();
            }
            updateShiftKeyState(editorInfo);
            return;
        }
        if (i != 2) {
            if (i == 3) {
                this.mCurKeyboard = this.enSymbolsKeyboard;
                return;
            } else if (i != 4) {
                if (this.lngCode == 0) {
                    this.mCurKeyboard = this.mEngKeyboard;
                } else {
                    this.mCurKeyboard = this.mEngKeyboard;
                }
                updateShiftKeyState(editorInfo);
                return;
            }
        }
        this.mCurKeyboard = this.enSymbolsKeyboard;
    }

    @Override // android.inputmethodservice.InputMethodService
    public void onFinishInput() {
        super.onFinishInput();
        this.mComposing.setLength(0);
        updateCandidates();
        setCandidatesViewShown(false);
        this.mCurKeyboard = this.mEngKeyboard;
        KeyboardView keyboardView = this.mInputView;
        if (keyboardView != null) {
            keyboardView.closing();
//            this.isTranslatorOn = false;
        }

        Log.e(TAG, "onFinishInput: " );
    }

    @Override // android.inputmethodservice.InputMethodService
    public void onStartInputView(EditorInfo editorInfo, boolean z) {
        super.onStartInputView(editorInfo, z);
        setInputView(onCreateInputView());
        onInitializeInterface();
        this.lngCode = this.mSharedPreferences.getInt("INPUT_LANGUAGE", 0);
        setKeyboardLanguage();
        this.mInputView.closing();
        Log.e(TAG, "onStartInputView: "+editorInfo.toString());


        // Get the InputConnection

    }

    @Override // android.inputmethodservice.InputMethodService
    public void onUpdateSelection(int i, int i2, int i3, int i4, int i5, int i6) {
        super.onUpdateSelection(i, i2, i3, i4, i5, i6);
        if (this.mComposing.length() <= 0) {
            return;
        }
        if (i3 == i6 && i4 == i6) {
            return;
        }
        this.mComposing.setLength(0);
        updateCandidates();
        InputConnection currentInputConnection = getCurrentInputConnection();
        if (currentInputConnection != null) {
            currentInputConnection.finishComposingText();
        }
        Log.e(TAG, "onUpdateSelection: " +getCurrentInputConnection() );
    }

    @Override // android.inputmethodservice.InputMethodService
    public void onDisplayCompletions(CompletionInfo[] completionInfoArr) {
        Log.e(TAG, "onDisplayCompletions: " );

        if (!this.mCompletionOn) {
            return;
        }
        this.mCompletions = completionInfoArr;
        if (completionInfoArr == null) {
            return;
        }
        ArrayList arrayList = new ArrayList();
        int i = 0;
        while (true) {
            if (i >= (completionInfoArr != null ? completionInfoArr.length : 0)) {
                return;
            }
            CompletionInfo completionInfo = completionInfoArr[i];
            if (completionInfo != null && completionInfo.getText() != null) {
                arrayList.add(completionInfo.getText().toString());
            }
            i++;
        }


    }

    @Override
    // android.inputmethodservice.InputMethodService, android.inputmethodservice.AbstractInputMethodService, android.app.Service
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    // android.inputmethodservice.InputMethodService, android.app.Service, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        InputConnection currentInputConnection = getCurrentInputConnection();
        if (this.mComposing.length() > 0 && currentInputConnection != null) {
            currentInputConnection.commitText(this.mComposing, 1);
        }
        super.onConfigurationChanged(configuration);
    }

    private boolean translateKeyDown(int i, KeyEvent keyEvent) {
        long handleKeyDown = MetaKeyKeyListener.handleKeyDown(this.mMetaState, i, keyEvent);
        this.mMetaState = handleKeyDown;
        int unicodeChar = keyEvent.getUnicodeChar(MetaKeyKeyListener.getMetaState(handleKeyDown));
        this.mMetaState = MetaKeyKeyListener.adjustMetaAfterKeypress(this.mMetaState);
        InputConnection currentInputConnection = getCurrentInputConnection();
        if (unicodeChar == 0 || currentInputConnection == null) {
            return false;
        }
        if (this.mComposing.length() > 0) {
            StringBuilder sb = this.mComposing;
            int deadChar = KeyEvent.getDeadChar(sb.charAt(sb.length() - 1), unicodeChar);
            if (deadChar != 0) {
                StringBuilder sb2 = this.mComposing;
                sb2.setLength(sb2.length() - 1);
                unicodeChar = deadChar;
            }
        }
        onKey(unicodeChar, null);
        return PROCESS_HARD_KEYS;
    }

    @Override // android.inputmethodservice.InputMethodService, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        KeyboardView keyboardView;
        InputConnection currentInputConnection;
        if (i == 4) {
            if (keyEvent.getRepeatCount() == 0 && (keyboardView = this.mInputView) != null && keyboardView.handleBack()) {
                return PROCESS_HARD_KEYS;
            }
            return false;
        } else if (i != 66) {
            if (i == 67) {
                if (this.mComposing.length() > 0) {
                    onKey(-5, null);
                    return PROCESS_HARD_KEYS;
                }
            } else if (i == 62 && (keyEvent.getMetaState() & 2) != 0 && (currentInputConnection = getCurrentInputConnection()) != null) {
                currentInputConnection.clearMetaKeyStates(2);
                keyDownUp(29);
                keyDownUp(42);
                keyDownUp(32);
                keyDownUp(46);
                keyDownUp(43);
                keyDownUp(37);
                keyDownUp(32);
                return PROCESS_HARD_KEYS;
            } else if (this.mPredictionOn && translateKeyDown(i, keyEvent)) {
                return PROCESS_HARD_KEYS;
            }
            return super.onKeyDown(i, keyEvent);
        } else {
            return false;
        }
    }

    @Override // android.inputmethodservice.InputMethodService, android.view.KeyEvent.Callback
    public boolean onKeyLongPress(int i, KeyEvent keyEvent) {
        KeyboardView keyboardView;
        InputConnection currentInputConnection;
        if (i == 4) {
            if (keyEvent.getRepeatCount() == 0 && (keyboardView = this.mInputView) != null && keyboardView.handleBack()) {
                return PROCESS_HARD_KEYS;
            }
            return false;
        } else if (i != 66) {
            if (i == 67) {
                if (this.mComposing.length() > 0) {
                    onKey(-5, null);
                    return PROCESS_HARD_KEYS;
                }
            } else if (i == 62 && (keyEvent.getMetaState() & 2) != 0 && (currentInputConnection = getCurrentInputConnection()) != null) {
                currentInputConnection.clearMetaKeyStates(2);
                keyDownUp(29);
                keyDownUp(42);
                keyDownUp(32);
                keyDownUp(46);
                keyDownUp(43);
                keyDownUp(37);
                keyDownUp(32);
                return PROCESS_HARD_KEYS;
            } else if (this.mPredictionOn && translateKeyDown(i, keyEvent)) {
                return PROCESS_HARD_KEYS;
            }
            return super.onKeyLongPress(i, keyEvent);
        } else {
            return false;
        }
    }

    @Override // android.inputmethodservice.InputMethodService, android.view.KeyEvent.Callback
    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (this.mPredictionOn) {
            this.mMetaState = MetaKeyKeyListener.handleKeyUp(this.mMetaState, i, keyEvent);
        }
        return super.onKeyUp(i, keyEvent);
    }

    private void commitTyped(InputConnection inputConnection) {
        commitTyped(inputConnection, 0);
    }

    private void commitTyped(InputConnection inputConnection, int i) {
        if (this.mComposing.length() > 0) {
            inputConnection.commitText(this.mComposing, 1);
            if (this.mAutoSpace == "ADD_SPACE") {
                this.mAutoSpace = "";
            }
            this.mComposing.setLength(0);
            updateCandidates();
        }
    }

    private void updateShiftKeyState(EditorInfo editorInfo) {
        if (editorInfo == null || this.mInputView == null) {
            return;
        }
        EditorInfo currentInputEditorInfo = getCurrentInputEditorInfo();
        boolean z = false;
        int cursorCapsMode = (currentInputEditorInfo == null || currentInputEditorInfo.inputType == 0) ? 0 : getCurrentInputConnection().getCursorCapsMode(editorInfo.inputType);
        if (this.mCapsLocked || cursorCapsMode != 0) {
            z = PROCESS_HARD_KEYS;
        }
        this.mCapsLock = z;
        this.mInputView.setShifted(z);
    }

    private boolean isAlphabet(int i) {
        if (Character.isLetter(i) || Character.isDigit(i)) {
            return PROCESS_HARD_KEYS;
        }
        return false;
    }

    private void keyDownUp(int i) {
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(0, i));
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(1, i));
    }

    private void sendKey(int i) {
        if (i == 10) {
            keyDownUp(66);
        } else if (i < 48 || i > 57) {
            getCurrentInputConnection().commitText(String.valueOf((char) i), 1);
        } else {
            keyDownUp((i - 48) + 7);
        }
    }

    @Override // android.inputmethodservice.KeyboardView.OnKeyboardActionListener
    public void onKey(int i, int[] iArr) {
       /* if (this.isTranslatorOn) {
            this.etTranslateValue.onCreateInputConnection(new EditorInfo());
            if (getCurrentInputConnection() != null) {
                Log.d("test", "onKey " + i);
                if (i == -5) {
                    int length = this.etTranslateValue.getText().length();
                    if (length > 0) {
                        this.etTranslateValue.getText().delete(length - 1, length);
                    }
                } else if (i == -1) {
                    handleShift();
                } else if (i == -3) {
                    handleClose();
                } else if (i == -2) {
                    handleModeChange();
                } else if (i == -11) {
                    handleEngShift();
                } else if (i == -12) {
                    handleEngBack();
                } else if (i == -15) {
                    enableEnglish();
                } else if (i == -100) {
                    handleChange();
                } else if (i == -200) {
                    handleEngSymbols();
                } else {
                    if (i >= 65 && i <= 90 && !this.mCapsLock) {
                        handleEngBack();
                    }
                    InputConnection onCreateInputConnection = this.etTranslateValue.onCreateInputConnection(new EditorInfo());
                    if (this.mCapsLock) {
                        onCreateInputConnection.commitText(String.valueOf((char) i).toUpperCase(), 1);
                    } else {
                        onCreateInputConnection.commitText(String.valueOf((char) i), 1);
                    }
                }
            }
        } else*/

        Log.e(TAG, "onKey: "+ iArr.toString());

       /* InputConnection inputConnection = getCurrentInputConnection();

        // Now you can use inputConnection to get the text the user is typing
        CharSequence textBeingTyped = inputConnection.getTextBeforeCursor(1000, 0);

        // Do something with the typed text
        Log.e(TAG,"===> "+ textBeingTyped.toString());

        correct_txt.setText(textBeingTyped.toString());*/


        if (isWordSeparator(i)) {
            if (isSpecialSeparator(i)) {
                handleCharacter(i, iArr);
                this.mInputView.getKeyboard();
                return;
            }
            commitTyped(getCurrentInputConnection());
            sendKey(i);
            updateShiftKeyState(getCurrentInputEditorInfo());
        } else if (i == -5) {
            handleBackspace();
        } else if (i == -1) {
            handleShift();
        } else if (i == -3) {
            handleClose();
        } else if (i == -2) {
            handleModeChange();
        } else if (i == -11) {
            handleEngShift();
        } else if (i == -12) {
            handleEngBack();
        } else if (i == -15) {
            enableEnglish();
        } else if (i == -100) {
            handleChange();
        } else if (i == -200) {
            handleEngSymbols();
        } else {
            if (i >= 65 && i <= 90 && !this.mCapsLock) {
                handleEngBack();
            }
            handleCharacter(i, iArr);
        }
    }

    private void handleEngBack() {
        this.mInputView.setKeyboard(this.mEngKeyboard);
        this.mCapsLock = false;
    }

    @Override // android.inputmethodservice.KeyboardView.OnKeyboardActionListener
    public void onText(CharSequence charSequence) {
       /* if (this.isTranslatorOn) {
            this.etTranslateValue.onCreateInputConnection(new EditorInfo()).commitText(charSequence, 1);
            return;
        }*/
        Log.e(TAG, "onText: "+getCurrentInputConnection() );
        InputConnection currentInputConnection = getCurrentInputConnection();
        if (currentInputConnection != null) {
            currentInputConnection.beginBatchEdit();
            commitTyped(currentInputConnection);
            currentInputConnection.commitText(charSequence, 0);
            currentInputConnection.endBatchEdit();
            updateShiftKeyState(getCurrentInputEditorInfo());
        }
    }

    private void updateCandidates() {
        if (this.mCompletionOn || this.mComposing.length() <= 0) {
            return;
        }
        new ArrayList().add(this.mComposing.toString());
        bindSuggestions(getCurrentInputConnection().getExtractedText(new ExtractedTextRequest(), 0).text.toString().replaceAll("[^a-zA-Z0-9]", " "));
    }

    public void handleBackspace() {
        bindSuggestions(getCurrentInputConnection().getExtractedText(new ExtractedTextRequest(), 0).text.toString().replaceAll("[^a-zA-Z0-9]", " "));
        keyDownUp(67);
        updateShiftKeyState(getCurrentInputEditorInfo());
        commitTyped(getCurrentInputConnection());
    }

    private void handleShift() {
        KeyboardView keyboardView = this.mInputView;
        if (keyboardView != null) {
            Keyboard keyboard = keyboardView.getKeyboard();
            if (keyboard == this.mEngKeyboard) {
                this.mInputView.setKeyboard(this.mEngKeyboardC);
                this.mCapsLock = false;
            } else if (keyboard == this.enSymbolsKeyboard) {
                this.mInputView.setKeyboard(this.enSymbolsCKeyboard);
            }
        }
    }

    private void handleEngShift() {
        this.mInputView.setKeyboard(this.mEngKeyboardShift);
        this.mCapsLock = PROCESS_HARD_KEYS;
    }

    private void handleChange() {
        KeyboardView keyboardView = this.mInputView;
        if (keyboardView != null) {
            keyboardView.getKeyboard();
        }
    }
//    private StringBuilder enteredText = new StringBuilder();

    private void handleCharacter(int i, int[] iArr) {





        if (isInputViewShown() && this.mInputView.isShifted()) {
            i = Character.toUpperCase(i);
        }
        if (!this.mPredictionOn) {
            commitTextAsIs(i);
        }

//        enteredText.append((char) i);
//        Log.e(TAG, "Entered Text: " + enteredText.toString());



        if (isAlphabet(i) && this.mPredictionOn) {
            this.mComposing.append((char) i);
            getCurrentInputConnection().setComposingText(this.mComposing, 1);
            getCurrentInputConnection().getExtractedText(new ExtractedTextRequest(), 0).text.toString();
            updateShiftKeyState(getCurrentInputEditorInfo());
            updateCandidates();
            return;
        }
        if (this.mAutoCompletionOn) {
            commitTyped(getCurrentInputConnection());
            commitTextAsIs(i);
        } else {
            getCurrentInputConnection().commitText(this.mComposing, 1);
            getCurrentInputConnection().getExtractedText(new ExtractedTextRequest(), 0).text.toString();
            commitTextAsIs(i);
        }
        updateShiftKeyState(getCurrentInputEditorInfo());


    }

    private void commitTextAsIs(int i) {
        getCurrentInputConnection().commitText(String.valueOf(Character.toChars(i)), 1);
        getCurrentInputConnection().setComposingText("", 1);
    }

    private void handleClose() {
        commitTyped(getCurrentInputConnection());
        requestHideSelf(0);
        this.mInputView.closing();
    }

    private void enableEnglish() {
        KeyboardView keyboardView = this.mInputView;
        if (keyboardView != null) {
            keyboardView.getKeyboard();
            this.mInputView.setKeyboard(this.mEngKeyboard);
            setLanguageCode(1);
        }
    }

    private void handleModeChange() {
        KeyboardView keyboardView = this.mInputView;
        if (keyboardView != null) {
            Keyboard keyboard = keyboardView.getKeyboard();
            keyboard.setShifted(false);
            this.mInputView.setKeyboard(keyboard);
        }
    }

    private void handleEngSymbols() {
        KeyboardView keyboardView = this.mInputView;
        if (keyboardView != null) {
            keyboardView.getKeyboard();
            this.mInputView.setKeyboard(this.enSymbolsKeyboard);
        }
    }

    public void setLanguageCode(int i) {
        SharedPreferences.Editor edit = this.mSharedPreferences.edit();
        this.editor = edit;
        edit.putInt("INPUT_LANGUAGE", i);
        this.editor.commit();
    }

    public boolean isWordSeparator(int i) {
        return this.mWordSeparators.contains(String.valueOf((char) i));
    }

    public boolean isSpecialSeparator(int i) {
        return this.mSpecialSeparators.contains(String.valueOf((char) i));
    }

    public void pickDefaultCandidate() {
        pickSuggestionManually(0);
    }

    public void pickSuggestionManually(int i) {
        CompletionInfo[] completionInfoArr;
        if (this.mCompletionOn && (completionInfoArr = this.mCompletions) != null && i >= 0 && i < completionInfoArr.length) {
            CompletionInfo completionInfo = completionInfoArr[i];
            PrintStream printStream = System.out;
            printStream.println("ci ->->->> " + completionInfo);
            getCurrentInputConnection().commitCompletion(completionInfo);
            updateShiftKeyState(getCurrentInputEditorInfo());
        } else if (this.mComposing.length() > 0) {
            PrintStream printStream2 = System.out;
            printStream2.println("index " + i);
            this.mAutoSpace = "ADD_SPACE";
            commitTyped(getCurrentInputConnection(), i);
        } else if (this.mComposing.length() == 0) {
            PrintStream printStream3 = System.out;
            printStream3.println("index " + i);
            this.mAutoSpace = "ADD_SPACE";
            commitTyped(getCurrentInputConnection(), i);
        }
    }

    @Override // android.inputmethodservice.KeyboardView.OnKeyboardActionListener
    public void swipeRight() {
        if (this.mCompletionOn) {
            pickDefaultCandidate();
        }
    }

    @Override // android.inputmethodservice.KeyboardView.OnKeyboardActionListener
    public void swipeLeft() {
        handleBackspace();
    }

    @Override // android.inputmethodservice.KeyboardView.OnKeyboardActionListener
    public void swipeDown() {
        handleClose();
    }

    @Override // android.inputmethodservice.KeyboardView.OnKeyboardActionListener
    public void onPress(int i) {

//        Log.e(TAG, "onPress:i===>  " + i);
        if (i == -1 || i == -2 || i == -11 || i == -12 || i == -17 || i == -15 || i == 10 || i == 32 || i == -100 || i == -200 || i == -16) {
            this.mInputView.setPreviewEnabled(false);
            return;
        }
        try {
            if (this.mPreview) {
                this.mInputView.setPreviewEnabled(PROCESS_HARD_KEYS);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override // android.inputmethodservice.KeyboardView.OnKeyboardActionListener
    public void onRelease(int i) {
        this.mInputView.setPreviewEnabled(false);
    }

    @Override // android.content.SharedPreferences.OnSharedPreferenceChangeListener
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String str) {
        loadPreviewPreferences(sharedPreferences);
        loadAutocompletionPreferences(sharedPreferences);
        loadPredictionPreferences(sharedPreferences);
    }

    private void loadPredictionPreferences(SharedPreferences sharedPreferences) {
        this.mPredictionOn = this.mSharedPreferences.getBoolean("prefPrediction", PROCESS_HARD_KEYS);
    }

    private void loadAutocompletionPreferences(SharedPreferences sharedPreferences) {
        this.mAutoCompletionOn = this.mSharedPreferences.getBoolean("prefAutoComplate", false);
    }

    private void loadPreviewPreferences(SharedPreferences sharedPreferences) {
        this.mPreview = this.mSharedPreferences.getBoolean("prefKeyPreview", PROCESS_HARD_KEYS);
    }

    public void bindSuggestions(String str) {
        try {
            if (this.rl_suggestion.getVisibility() == View.GONE) {
                this.rl_suggestion.setVisibility(View.VISIBLE);
            }
            String[] split = str.split(" ");
            this.currentSuggestion = split[split.length - 1];
            this.suggestionModels.clear();
            this.suggestionModels = this.databaseHelper.getSuggestions(split[split.length - 1]);
            SuggestionAdapter suggestionAdapter = new SuggestionAdapter(this.suggestionModels, this, this);
            this.suggestionAdapter = suggestionAdapter;
            this.rvSuggestions.setAdapter(suggestionAdapter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override // spell.check.keyboard.spelling.corrections.OnClickInterface.OnItemClickListener
    public void OnClick(View view, int i) {
        this.databaseHelper.updateFrequentlyWord(this.suggestionModels.get(i).getId());

        InputConnection currentInputConnection = getCurrentInputConnection();
        currentInputConnection.setComposingText("", 0);
        currentInputConnection.setComposingText(this.suggestionModels.get(i).getWord(), 1);
        currentInputConnection.sendKeyEvent(new KeyEvent(0, 62));
        currentInputConnection.commitText(this.suggestionModels.get(i).getWord(), 1);
    }

}
