package spell.check.keyboard.spelling.corrections.enablekeyboard;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;

/* loaded from: classes.dex */
public final class SharedPreferenceclass {
    SharedPreferences.Editor editor;
    private final SharedPreferences prefs;

    public SharedPreferenceclass(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("THEME_KEY", 0);
        this.editor = sharedPreferences.edit();
        if (sharedPreferences != null) {
            this.prefs = sharedPreferences;
            return;
        }
        throw new NullPointerException(sharedPreferences.toString());
    }

    public void setImage(String str, String str2) {
        this.prefs.edit().putString(str, str2).apply();
    }

    public String getImage(String str, Drawable drawable) {
        return this.prefs.getString(str, String.valueOf(drawable));
    }
}
