package spell.check.keyboard.spelling.corrections.common;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import spell.check.keyboard.spelling.corrections.MainActivity;
import spell.check.keyboard.spelling.corrections.R;

/* loaded from: classes.dex */
public class TapToStartActivity extends AppCompatActivity {
    public static final String ACTION_CLOSE = "ACTION_CLOSE";
    Activity activity;
    LinearLayout btn_start;
    Context context;
    private FirstReceiver firstReceiver;
    private Context mContext;
    TextView txt_privacyPolicy;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.addFlags(Integer.MIN_VALUE);
            window.clearFlags(67108864);
            window.setStatusBarColor(getResources().getColor(R.color.start_color));
        }
        setContentView(R.layout.taptostart_activity);
        this.mContext = this;
        this.context = this;
        this.activity = this;
        this.btn_start = (LinearLayout) findViewById(R.id.btn_start);
        this.txt_privacyPolicy = (TextView) findViewById(R.id.txt_privacy);
        this.txt_privacyPolicy.setText(Html.fromHtml("<a href='https://appsforlightinc.wixsite.com/appsforlightinc'>Privacy Policy</a>"));
        this.txt_privacyPolicy.setOnClickListener(new View.OnClickListener() { // from class: spell.check.keyboard.spelling.corrections.common.TapToStartActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {

            }
        });
        this.btn_start.setOnClickListener(new View.OnClickListener() { // from class: spell.check.keyboard.spelling.corrections.common.TapToStartActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent(TapToStartActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                TapToStartActivity.this.startActivity(intent);
            }
        });
        IntentFilter intentFilter = new IntentFilter("ACTION_CLOSE");
        FirstReceiver firstReceiver = new FirstReceiver();
        this.firstReceiver = firstReceiver;
        registerReceiver(firstReceiver, intentFilter);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
       finish();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(this.firstReceiver);
    }

    /* loaded from: classes.dex */
    class FirstReceiver extends BroadcastReceiver {
        FirstReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            Log.e("FirstReceiver", "FirstReceiver");
            if (intent.getAction().equals("ACTION_CLOSE")) {
                TapToStartActivity.this.finish();
            }
        }
    }
}
